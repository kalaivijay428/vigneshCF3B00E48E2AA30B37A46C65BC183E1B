"""
1!=1x1
2!=2x1! ---->2x1
3!=3x2! ----->3x2x1
.
.
10!=10x9! ---->10x9x8x...x1
formula - n x (n-1)!
"""
def fact_rec(n):
  if n==1 or n==1:
    return 1
  else:
    return n*fact_rec(n-1)
number=2
res=fact_rec(number)
print("the factorial of {} is {}.".format(number,res))